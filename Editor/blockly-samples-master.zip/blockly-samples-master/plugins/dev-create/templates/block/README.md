# @blockly/plugin [![Built on Blockly](https://tinyurl.com/built-on-blockly)](https://github.com/google/blockly)

<!--
  - TODO: Add block description.
  -->
A [Blockly](https://www.npmjs.com/package/blockly) block that ...

## Installation

### Yarn
```
yarn add @blockly/plugin
```

### npm
```
npm install @blockly/plugin --save
```

## Usage

### Import
```js
import * as Blockly from 'blockly';
import '@blockly/plugin';

```

## License
Apache 2.0
