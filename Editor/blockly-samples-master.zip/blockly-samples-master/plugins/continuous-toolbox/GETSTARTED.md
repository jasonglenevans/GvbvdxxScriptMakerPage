## Available Scripts

In this directory, you can run:

### `npm start`

Runs the package in development mode.

Open [http://localhost:3000/test](http://localhost:3000/test) to view the test
playground in the browser. The page will reload if you make edits.

### `npm run build`

Builds the package into the `dist` directory.

### `npm run lint`

Runs eslint on the `src` and `test` directories.

### `npm run clean`

Deletes the `dist` and `build` directories if they exist.
