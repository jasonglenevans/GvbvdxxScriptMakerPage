# @blockly/eslint-config [![Built on Blockly](https://tinyurl.com/built-on-blockly)](https://github.com/google/blockly)

> ESLint [shareable config](http://eslint.org/docs/developer-guide/shareable-configs.html) used by [Blockly plugins](https://github.com/google/blockly-samples/tree/master/plugins)


## Installation

```
$ npm install --save-dev eslint @blockly/eslint-config
```

## License

Apache 2.0
