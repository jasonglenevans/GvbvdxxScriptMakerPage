Starter code and completed code for the [codelab](https://blocklycodelabs.dev/codelabs/custom_toolbox/index.html) on how to customize your toolbox.

The completed code overrides various methods on the default category class to
change the look of the toolbox. It also adds a new toolbox item class that creates
a label in the toolbox.
