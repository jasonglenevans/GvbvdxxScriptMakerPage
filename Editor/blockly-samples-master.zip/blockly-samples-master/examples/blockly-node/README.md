[Home](../README.md)

# blockly-node-sample [![Built on Blockly](https://tinyurl.com/built-on-blockly)](https://github.com/google/blockly)

This sample shows how to load Blockly in a [Node.js](https://nodejs.org/) environment using ``CommonJS``.


## Installation

```
npm install
```

## Running

```
npm run start
```